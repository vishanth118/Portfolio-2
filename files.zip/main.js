/* =====================================================
   SILVER SURFER 3D PORTFOLIO — main.js
   A scroll-driven particle scene (Three.js r128).
   Each <section class="panel"> in index.html gets one "stage".
   As you scroll, the particles morph from one shape to the next.
   ===================================================== */

/* ---------------- CONFIG — tweak me ---------------- */
const CONFIG = {
  particles: { desktop: 26000, mobile: 11000 },   // more = denser, heavier
  cameraZ:   { desktop: 8.5,   mobile: 11 },
  stars: 2200,
  mouseRepel: true,                               // particles push away from the cursor

  // One entry per section, SAME ORDER as the panels in index.html.
  // shape: 'surfer' | 'orb' | 'galaxy'
  // x / y: position · scale · tiltX/rotY: rotation (radians) · spin: 1 = slowly rotates · dim: brightness
  stages: [
    { shape: 'surfer', x:  2.5, y: -0.2, scale: 1.0,  tiltX: 0.05, rotY: -0.6, spin: 0, dim: 1.0  },
    { shape: 'orb',    x: -2.7, y:  0.0, scale: 1.0,  tiltX: 0.30, rotY:  0.2, spin: 1, dim: 1.0  },
    { shape: 'galaxy', x:  0.0, y:  0.0, scale: 1.45, tiltX: 1.00, rotY:  0.0, spin: 1, dim: 0.45 },
    { shape: 'surfer', x:  2.5, y: -0.2, scale: 1.1,  tiltX: 0.05, rotY: -0.9, spin: 0, dim: 1.0  },
  ],
};

/* =====================================================
   SHAPES — pure maths, no Three.js needed here.
   Each generator returns { pos: Float32Array, col: Float32Array } (N points).
   ===================================================== */
// <shapes>
const rnd = (a = 0, b = 1) => a + Math.random() * (b - a);
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5; // ~ -1..1, bell-shaped
function unitVec() {
  const u = rnd(-1, 1), th = rnd(0, Math.PI * 2), r = Math.sqrt(1 - u * u);
  return [r * Math.cos(th), u, r * Math.sin(th)];
}

// Palette (r, g, b in 0..1) — edit freely
const PAL = {
  silver: [0.82, 0.89, 1.0],
  steel:  [0.45, 0.58, 0.82],
  cyan:   [0.25, 0.85, 1.0],
  violet: [0.55, 0.40, 1.0],
  gold:   [1.0,  0.78, 0.38],
  blue:   [0.22, 0.50, 1.0],
  white:  [1, 1, 1],
};
const mixc = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const scalec = (c, s) => [Math.min(1.3, c[0] * s), Math.min(1.3, c[1] * s), Math.min(1.3, c[2] * s)];

function makeBuffer(N) { return { n: N, k: 0, pos: new Float32Array(N * 3), col: new Float32Array(N * 3) }; }
function put(B, x, y, z, c) {
  const i = B.k * 3;
  B.pos[i] = x; B.pos[i + 1] = y; B.pos[i + 2] = z;
  B.col[i] = c[0]; B.col[i + 1] = c[1]; B.col[i + 2] = c[2];
  B.k++;
}
function finish(B) {                      // safety: pad to exactly N points
  while (B.k < B.n) {
    const j = Math.floor(Math.random() * Math.max(1, B.k)) * 3;
    put(B, B.pos[j], B.pos[j + 1], B.pos[j + 2], [B.col[j], B.col[j + 1], B.col[j + 2]]);
  }
  return { pos: B.pos, col: B.col };
}

/* ---- THE SILVER SURFER: a figure on a board, with a cosmic trail ---- */
function makeSurfer(N) {
  const B = makeBuffer(N), OY = -1.25;    // OY centres the figure vertically
  const nBody = Math.floor(N * 0.50), nBoard = Math.floor(N * 0.27);

  // Body parts: capsules (a → b with radius r0 → r1) and one ellipsoid (head). w = share of particles.
  const parts = [
    { t: 'cap', a: [0, 1.2, 0],       b: [0, 2.05, 0],       r0: .27, r1: .31, w: 3.2 }, // torso
    { t: 'ell', c: [0.05, 2.47, 0],   r: [.19, .26, .19],                       w: 1.6 }, // head
    { t: 'cap', a: [-.1, 1.2, 0],     b: [-.42, .68, .08],   r0: .16, r1: .13, w: 1.5 }, // back thigh
    { t: 'cap', a: [-.42, .68, .08],  b: [-.6, .1, 0],       r0: .13, r1: .09, w: 1.4 }, // back shin
    { t: 'cap', a: [.1, 1.2, 0],      b: [.45, .7, .08],     r0: .16, r1: .13, w: 1.5 }, // front thigh
    { t: 'cap', a: [.45, .7, .08],    b: [.6, .1, 0],        r0: .13, r1: .09, w: 1.4 }, // front shin
    { t: 'cap', a: [-.3, 1.98, 0],    b: [-.85, 1.72, .15],  r0: .1,  r1: .08, w: 1.2 }, // back upper arm
    { t: 'cap', a: [-.85, 1.72, .15], b: [-1.35, 1.95, .2],  r0: .08, r1: .06, w: 1.1 }, // back forearm
    { t: 'cap', a: [.3, 1.98, 0],     b: [.85, 2.3, .15],    r0: .1,  r1: .08, w: 1.2 }, // front upper arm
    { t: 'cap', a: [.85, 2.3, .15],   b: [1.3, 2.65, .2],    r0: .08, r1: .06, w: 1.1 }, // front forearm
  ];
  const totalW = parts.reduce((s, p) => s + p.w, 0);

  for (let n = 0; n < nBody; n++) {
    let r = Math.random() * totalW, p = parts[0];
    for (const q of parts) { if (r < q.w) { p = q; break; } r -= q.w; }
    const u = unitVec(), s = 0.8 + 0.2 * Math.random();
    let x, y, z;
    if (p.t === 'cap') {
      const t = Math.random(), rad = (p.r0 + (p.r1 - p.r0) * t) * s;
      x = p.a[0] + (p.b[0] - p.a[0]) * t + u[0] * rad;
      y = p.a[1] + (p.b[1] - p.a[1]) * t + u[1] * rad;
      z = p.a[2] + (p.b[2] - p.a[2]) * t + u[2] * rad;
    } else {
      x = p.c[0] + u[0] * p.r[0] * s; y = p.c[1] + u[1] * p.r[1] * s; z = p.c[2] + u[2] * p.r[2] * s;
    }
    // fake lighting from the upper-front → liquid-chrome look
    const lit = 0.55 + 0.45 * Math.max(0, u[0] * 0.4 + u[1] * 0.7 + u[2] * 0.6);
    let c = mixc(PAL.steel, PAL.silver, lit);
    if (Math.random() < 0.06) c = PAL.white;               // chrome sparkles
    put(B, x, y + OY, z, scalec(c, 0.8 + 0.4 * Math.random()));
  }

  // Board: a pointed lens shape, glowing cyan rim + centre stripe
  const L = 1.95, W = 0.45;
  for (let n = 0; n < nBoard; n++) {
    let x, y, z, c;
    if (Math.random() < 0.3) {                              // rim
      const th = rnd(0, Math.PI * 2), u = Math.cos(th);
      const w = W * Math.pow(Math.max(0, 1 - u * u), 0.6);
      x = L * u; z = w * Math.sign(Math.sin(th)); y = rnd(-0.03, 0.03);
      c = mixc(PAL.cyan, PAL.white, Math.random() * 0.5);
    } else {                                                // top & bottom surface
      const u = rnd(-1, 1), w = W * Math.pow(1 - u * u, 0.6);
      x = u * L; z = rnd(-w, w);
      y = (Math.random() < 0.5 ? 1 : -1) * (0.07 * (1 - u * u) + 0.012);
      c = Math.abs(z) < 0.03 ? PAL.cyan : mixc(PAL.steel, PAL.silver, Math.random());
    }
    put(B, x, y + OY, z, c);
  }

  // Cosmic trail streaming behind the board
  while (B.k < N) {
    const d = Math.pow(Math.random(), 1.5), spread = 0.06 + d * 0.55;
    const x = -L - 0.1 - d * 3.6;
    const y = rnd(-spread, spread) * 0.8 + Math.sin(x * 2.2) * 0.08 * d;
    const z = rnd(-spread, spread);
    put(B, x, y + OY, z, scalec(mixc(PAL.cyan, PAL.violet, d), 1 - d * 0.5));
  }
  return finish(B);
}

/* ---- ORB: a planet with a ring + floating sparks ---- */
function makeOrb(N) {
  const B = makeBuffer(N), R = 2.0, tilt = 0.45;
  const nS = Math.floor(N * 0.68), nR = Math.floor(N * 0.25);
  for (let n = 0; n < nS; n++) {                            // sphere surface
    const u = unitVec();
    const t = 0.5 + 0.5 * Math.sin(u[0] * 3.1 + u[1] * 2.2) * Math.cos(u[2] * 2.7 + u[1] * 1.3);
    put(B, u[0] * R, u[1] * R, u[2] * R, scalec(mixc(PAL.blue, PAL.gold, t), 0.7 + 0.5 * Math.random()));
  }
  for (let n = 0; n < nR; n++) {                            // ring
    const a = rnd(0, Math.PI * 2), r = rnd(2.8, 4.0), y0 = rnd(-0.05, 0.05);
    const x0 = r * Math.cos(a), z = r * Math.sin(a);
    const x = x0 * Math.cos(tilt) - y0 * Math.sin(tilt), y = x0 * Math.sin(tilt) + y0 * Math.cos(tilt);
    put(B, x, y, z, scalec(mixc(PAL.silver, PAL.cyan, (r - 2.8) / 1.2), 0.7 + 0.5 * Math.random()));
  }
  while (B.k < N) {                                         // sparks
    const u = unitVec(), r = rnd(4.2, 5.6);
    put(B, u[0] * r, u[1] * r, u[2] * r, mixc(PAL.gold, PAL.white, Math.random()));
  }
  return finish(B);
}

/* ---- GALAXY: spiral arms with a glowing core ---- */
function makeGalaxy(N) {
  const B = makeBuffer(N), nCore = Math.floor(N * 0.12);
  for (let n = 0; n < nCore; n++) {
    const u = unitVec(), r = 0.7 * Math.sqrt(Math.random());
    put(B, u[0] * r, u[1] * r * 0.6, u[2] * r, mixc(PAL.gold, PAL.white, 0.5));
  }
  while (B.k < N) {
    const r = Math.pow(Math.random(), 0.65) * 4.2 + 0.2, arm = Math.floor(Math.random() * 3);
    const ang = (arm * Math.PI * 2) / 3 + r * 0.9 + (gauss() * 0.28) / (0.4 + r * 0.15);
    const y = gauss() * 0.18 * Math.max(0.1, 1 - r / 5);
    const t = r / 4.4;
    const c = t < 0.4 ? mixc(PAL.gold, PAL.cyan, t / 0.4) : mixc(PAL.cyan, PAL.violet, (t - 0.4) / 0.6);
    put(B, r * Math.cos(ang), y, r * Math.sin(ang), scalec(c, 0.7 + 0.5 * Math.random()));
  }
  return finish(B);
}

const SHAPE_MAKERS = { surfer: makeSurfer, orb: makeOrb, galaxy: makeGalaxy };
// </shapes>

/* =====================================================
   THREE.JS SCENE
   ===================================================== */
(function start() {
  if (typeof THREE === 'undefined') {
    console.warn('Three.js failed to load (offline?). The page still works without the 3D scene.');
    return;
  }

  const canvas = document.getElementById('bg');
  const isMobile = () => window.innerWidth < 820;
  const N = isMobile() ? CONFIG.particles.mobile : CONFIG.particles.desktop;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: true, powerPreference: 'high-performance' });
  } catch (e) { console.warn('WebGL not available', e); return; }
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  renderer.setPixelRatio(DPR);
  renderer.setSize(window.innerWidth, window.innerHeight);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 200);
  camera.position.z = isMobile() ? CONFIG.cameraZ.mobile : CONFIG.cameraZ.desktop;

  /* ---- Build every shape once ---- */
  const shapes = {};
  CONFIG.stages.forEach(s => { if (!shapes[s.shape]) shapes[s.shape] = SHAPE_MAKERS[s.shape](N); });

  /* ---- Particle geometry: slot A = current shape, slot B = next shape ---- */
  const first = shapes[CONFIG.stages[0].shape];
  const geo = new THREE.BufferGeometry();
  const attrA = new THREE.BufferAttribute(new Float32Array(first.pos), 3).setUsage(THREE.DynamicDrawUsage);
  const attrB = new THREE.BufferAttribute(new Float32Array(first.pos), 3).setUsage(THREE.DynamicDrawUsage);
  const colA  = new THREE.BufferAttribute(new Float32Array(first.col), 3).setUsage(THREE.DynamicDrawUsage);
  const colB  = new THREE.BufferAttribute(new Float32Array(first.col), 3).setUsage(THREE.DynamicDrawUsage);
  const rand = new Float32Array(N), size = new Float32Array(N);
  for (let i = 0; i < N; i++) { rand[i] = Math.random(); size[i] = rnd(0.8, 2.2); }
  geo.setAttribute('position', attrA);
  geo.setAttribute('posB', attrB);
  geo.setAttribute('colA', colA);
  geo.setAttribute('colB', colB);
  geo.setAttribute('aRnd', new THREE.BufferAttribute(rand, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));

  const U = {
    uMix:     { value: 0 },
    uTime:    { value: 0 },
    uPx:      { value: DPR },
    uIntro:   { value: 1 },
    uDim:     { value: 1 },
    uMouse:   { value: new THREE.Vector3(999, 999, 0) },
    uMouseOn: { value: 0 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms: U,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      attribute vec3 posB;
      attribute vec3 colA;
      attribute vec3 colB;
      attribute float aRnd;
      attribute float aSize;
      uniform float uMix, uTime, uPx, uIntro, uDim, uMouseOn;
      uniform vec3 uMouse;
      varying vec3 vCol;
      varying float vAlpha;

      void main() {
        // each particle starts morphing at a slightly different moment
        float delay = aRnd * 0.45;
        float m = clamp((uMix - delay) / 0.55, 0.0, 1.0);
        m = m * m * (3.0 - 2.0 * m);

        vec3 p = mix(position, posB, m);

        // burst outward mid-morph, and on the intro
        vec3 sc = vec3(sin(aRnd * 91.7), cos(aRnd * 57.3), sin(aRnd * 33.1));
        p += sc * sin(m * 3.14159) * 1.6;
        p += sc * uIntro * 7.0;

        // gentle floating motion
        p += vec3(sin(uTime * 0.7 + aRnd * 40.0),
                  cos(uTime * 0.8 + aRnd * 31.0),
                  sin(uTime * 0.6 + aRnd * 53.0)) * 0.035;

        vec4 wp = modelMatrix * vec4(p, 1.0);

        // cursor repel
        vec2 d = wp.xy - uMouse.xy;
        float push = smoothstep(1.6, 0.0, length(d)) * uMouseOn;
        wp.xy += normalize(d + 1e-4) * push * 0.7;
        wp.z  += push * 0.4;

        vec4 mv = viewMatrix * wp;
        gl_Position = projectionMatrix * mv;
        gl_PointSize = aSize * uPx * (16.0 / -mv.z);

        vCol = mix(colA, colB, m);
        vAlpha = (0.6 + 0.4 * sin(uTime * 2.0 + aRnd * 100.0)) * uDim;
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vCol;
      varying float vAlpha;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        if (d > 0.5) discard;
        float a = smoothstep(0.5, 0.0, d);
        gl_FragColor = vec4(vCol, a * a * vAlpha);
      }
    `,
  });

  const root = new THREE.Group();          // position / scale / tilt
  const points = new THREE.Points(geo, material); // spin
  points.frustumCulled = false;
  root.add(points);
  scene.add(root);

  /* ---- Starfield ---- */
  const starPos = new Float32Array(CONFIG.stars * 3);
  for (let i = 0; i < CONFIG.stars; i++) {
    starPos[i * 3] = rnd(-40, 40); starPos[i * 3 + 1] = rnd(-40, 40); starPos[i * 3 + 2] = rnd(-45, 5);
  }
  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({
    size: 0.09, color: 0xbfd2ff, transparent: true, opacity: 0.8, depthWrite: false, sizeAttenuation: true,
  }));
  scene.add(stars);

  /* ---- Slot loader: copies a shape into buffer A or B only when it changes ---- */
  const slot = { A: CONFIG.stages[0].shape, B: CONFIG.stages[0].shape };
  function setSlot(which, name) {
    if (slot[which] === name) return;
    slot[which] = name;
    const sh = shapes[name];
    const [pa, ca] = which === 'A' ? [attrA, colA] : [attrB, colB];
    pa.array.set(sh.pos); pa.needsUpdate = true;
    ca.array.set(sh.col); ca.needsUpdate = true;
  }

  /* ---- Input ---- */
  const mouse = { x: 0, y: 0 };
  const ray = new THREE.Raycaster();
  const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
  const hit = new THREE.Vector3();
  window.addEventListener('pointermove', e => {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -((e.clientY / window.innerHeight) * 2 - 1);
    U.uMouseOn.value = CONFIG.mouseRepel && e.pointerType === 'mouse' ? 1 : 0;
  });
  document.addEventListener('pointerleave', () => { U.uMouseOn.value = 0; });

  /* ---- Scroll → "section progress" (0 = first section, 1 = second, 1.5 = halfway between 2 and 3…) ---- */
  const panels = [...document.querySelectorAll('.panel')];
  let tops = [];
  const measure = () => { tops = panels.map(p => p.getBoundingClientRect().top + window.scrollY); };
  function sectionProgress() {
    const y = window.scrollY, n = Math.min(tops.length, CONFIG.stages.length);
    if (n < 2) return 0;
    if (y >= tops[n - 1]) return n - 1;
    let i = 0;
    while (i < n - 2 && y >= tops[i + 1]) i++;
    return i + (y - tops[i]) / (tops[i + 1] - tops[i]);
  }
  measure();
  window.addEventListener('load', measure);

  /* ---- Resize ---- */
  window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    measure();
  });
  if ('ResizeObserver' in window) new ResizeObserver(measure).observe(document.body);

  /* ---- UI niceties: reveal text, nav dots ---- */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => e.target.classList.toggle('in', e.isIntersecting));
  }, { threshold: 0.2 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  const dots = [...document.querySelectorAll('.dots a')];

  /* ---- Stage params (mobile: object moves to the top, smaller) ---- */
  function stageParams(i) {
    const s = CONFIG.stages[i];
    if (!isMobile()) return s;
    return Object.assign({}, s, { x: 0, y: s.shape === 'galaxy' ? 0 : 1.9, scale: s.scale * 0.62 });
  }
  const smooth = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const easeOut = t => 1 - Math.pow(1 - t, 3);

  /* ---- Main loop ---- */
  let sCur = 0, time = 0, last = performance.now(), spin = 0, lastDot = -1;
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000); last = now; time += dt;

    // smooth the scroll value so motion feels buttery
    sCur += (sectionProgress() - sCur) * (1 - Math.exp(-dt * 6));

    const n = CONFIG.stages.length;
    const i = Math.min(n - 1, Math.floor(sCur)), j = Math.min(n - 1, i + 1);
    const f = i === n - 1 ? 0 : sCur - i;
    const t = smooth(0.12, 0.88, f);               // stays on a shape, then morphs in the middle of the scroll

    setSlot('A', CONFIG.stages[i].shape);
    setSlot('B', CONFIG.stages[j].shape);
    U.uMix.value = t;

    const a = stageParams(i), b = stageParams(j);
    const L = k => a[k] + (b[k] - a[k]) * t;

    U.uTime.value = time;
    U.uIntro.value = 1 - easeOut(Math.min(1, time / 2.6));
    U.uDim.value = L('dim');

    spin += dt * 0.18;
    root.position.set(L('x'), L('y') + Math.sin(time * 0.9) * 0.12, 0);   // floating
    root.scale.setScalar(L('scale'));
    root.rotation.x = L('tiltX') + mouse.y * 0.08;
    root.rotation.z = Math.sin(time * 0.7) * 0.04;
    points.rotation.y = L('rotY') + Math.sin(time * 0.35) * 0.1 + (spin % (Math.PI * 2)) * L('spin') + mouse.x * 0.25;

    // mouse position on the z = 0 plane (for the repel effect)
    ray.setFromCamera({ x: mouse.x, y: mouse.y }, camera);
    if (ray.ray.intersectPlane(plane, hit)) U.uMouse.value.copy(hit);

    // slight camera parallax + starfield drift
    camera.position.x += (mouse.x * 0.4 - camera.position.x) * 0.05;
    camera.position.y += (mouse.y * 0.25 - camera.position.y) * 0.05;
    camera.lookAt(0, 0, 0);
    stars.rotation.y = time * 0.01 + sCur * 0.15;
    stars.position.y = sCur * 0.6;

    // nav dots
    const d = Math.round(sCur);
    if (d !== lastDot) { dots.forEach((el, k) => el.classList.toggle('active', k === d)); lastDot = d; }

    renderer.render(scene, camera);
  }
  requestAnimationFrame(frame);
})();
