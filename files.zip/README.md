# Silver Surfer 3D Portfolio

Scroll-driven particle portfolio (Three.js). A Silver Surfer made of ~26,000 glowing
particles rides his board, then morphs into a planet → a galaxy → back to the Surfer as you scroll.

## Run it
1. Open the folder in VS Code.
2. Double-click `index.html` **or** right-click → *Open with Live Server* (extension "Live Server") for auto-reload while you edit.
3. You need internet once per load (Three.js + Google Fonts come from CDNs).

## Edit it
| What | Where |
|---|---|
| Your name, bio, skills, projects, email, social links | `index.html` (look for `<!-- EDIT: ... -->`) |
| Colours, fonts | `:root { ... }` at the top of `style.css` |
| Particle count, positions, which shape per section | `CONFIG` at the top of `main.js` |
| Particle colours | `PAL` in `main.js` |
| The Surfer's pose / board / trail | `makeSurfer()` in `main.js` |

## Adding or removing a section
Each `<section class="panel">` needs one entry in `CONFIG.stages` (same order).
Shapes available: `'surfer'`, `'orb'`, `'galaxy'`.

## Tips
- Slow laptop? Lower `CONFIG.particles.desktop` to `15000`.
- Want the cursor to stop pushing particles? Set `mouseRepel: false`.
- Particle size: change `rnd(0.8, 2.2)` (the `size` array) in `main.js`.
